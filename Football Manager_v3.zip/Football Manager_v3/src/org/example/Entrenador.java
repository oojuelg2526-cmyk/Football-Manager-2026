package org.example;
import java.time.LocalDate;

public class Entrenador extends Persona {
    private int tornejos;
    private boolean esSeleccionador;

    public Entrenador(String nom, String cognom, LocalDate data, double mot, double sou,
                      int tornejos, boolean esSel) {
        super(nom, cognom, data, mot, sou);
        this.tornejos = tornejos; this.esSeleccionador = esSel;
    }
    // Constructor nou (motivació=5)
    public Entrenador(String nom, String cognom, LocalDate data, double sou, int tornejos, boolean esSel) {
        this(nom, cognom, data, 5.0, sou, tornejos, esSel);
    }

    public int getTornejos()          { return tornejos; }
    public boolean isEsSeleccionador(){ return esSeleccionador; }

    public void incrementarSou() {
        sou *= 1.005;
        System.out.println("  Sou " + getNom() + " -> " + String.format("%.0f", sou) + "EUR");
    }

    @Override public void entrenament() {
        setMotivacio(motivacio + (esSeleccionador ? 0.3 : 0.15));
        System.out.println("  " + getNom() + " mot:" + String.format("%.2f", motivacio));
    }

    @Override public String toString() {
        return String.format("%-20s Tornejos:%d Sel:%-3s M:%.1f Sou:%.0fEUR",
            getNom()+" "+getCognom(), tornejos, esSeleccionador?"Si":"No", getMotivacio(), getSou());
    }
}
