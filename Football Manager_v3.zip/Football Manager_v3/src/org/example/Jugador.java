package org.example;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.Objects;

public class Jugador extends Persona {
    public enum Posicio { POR, DEF, MIG, DAV }

    private int dorsal;
    private Posicio posicio;
    private double qualitat;
    private static int comptador = 0;

    public Jugador(String nom, String cognom, LocalDate data, double mot, double sou,
                   int dorsal, Posicio pos, double qualitat) {
        super(nom, cognom, data, mot, sou);
        this.dorsal = dorsal; this.posicio = pos; setQualitat(qualitat); comptador++;
    }
    // Constructor nou (motivació=5, qualitat aleatòria)
    public Jugador(String nom, String cognom, LocalDate data, double sou, int dorsal, Posicio pos) {
        this(nom, cognom, data, 5.0, sou, dorsal, pos, 30 + Math.random() * 70);
    }

    public int getDorsal()     { return dorsal; }
    public Posicio getPosicio(){ return posicio; }
    public double getQualitat(){ return qualitat; }
    public void setDorsal(int d) { dorsal = d; }
    public void setQualitat(double q) { qualitat = Math.max(30, Math.min(100, q)); }
    public static int getComptador() { return comptador; }

    public void canviDePosicio() {
        if (Math.random() < 0.05) {
            Posicio[] p = Posicio.values(); Posicio nova = posicio;
            while (nova == posicio) nova = p[(int)(Math.random() * p.length)];
            System.out.println("  " + getNom() + " canvia " + posicio + "->" + nova + " +1Q");
            posicio = nova; setQualitat(qualitat + 1);
        }
    }

    @Override public void entrenament() {
        super.entrenament();
        double r = Math.random(), inc = r < 0.7 ? 0.1 : r < 0.9 ? 0.2 : 0.3;
        setQualitat(qualitat + inc);
        System.out.println("  " + getNom() + " qualitat+" + inc + "=" + String.format("%.1f", qualitat));
    }

    @Override public boolean equals(Object o) {
        if (!(o instanceof Jugador)) return false;
        Jugador j = (Jugador) o; return dorsal == j.dorsal && Objects.equals(getNom(), j.getNom());
    }
    @Override public int hashCode() { return Objects.hash(getNom(), dorsal); }

    public static Comparator<Jugador> comparadorMercat() {
        return new Comparator<Jugador>() { public int compare(Jugador a, Jugador b) {
            int c = Double.compare(b.qualitat, a.qualitat); if (c != 0) return c;
            c = Double.compare(b.motivacio, a.motivacio);   if (c != 0) return c;
            return a.getCognom().compareTo(b.getCognom());
        }};
    }
    public static Comparator<Jugador> comparadorEquip() {
        return new Comparator<Jugador>() { public int compare(Jugador a, Jugador b) {
            int c = a.posicio.name().compareTo(b.posicio.name()); if (c != 0) return c;
            return Double.compare(b.qualitat, a.qualitat);
        }};
    }

    @Override public String toString() {
        return String.format("[%2d] %-20s %-3s Q:%4.1f M:%3.1f Sou:%8.0fEUR",
            dorsal, getNom()+" "+getCognom(), posicio, qualitat, getMotivacio(), getSou());
    }
}
