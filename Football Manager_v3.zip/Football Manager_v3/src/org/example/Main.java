package org.example;

import java.io.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
public class Main {
    private static final List<Equip>    equips  = new ArrayList<>();
    private static final List<Jugador>  mercat  = new ArrayList<>();
    private static final List<Entrenador> mentors = new ArrayList<>();
    private static Lliga lliga = null;
    private static final Scanner sc = new Scanner(System.in);
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // ── MAIN ────────────────────────────────────────────────────────
    public static void main(String[] args) {
        System.out.println("=== FOOTBALL MANAGER ===");
        carregarMercat("mercat_fitxatges.txt");
        carregarEquips("equips.txt");
        System.out.println("\nInicia sessió com a:");
        System.out.println("  1 – Admin");
        System.out.println("  2 – Gestor d'equip");
        System.out.print("Opció: ");
        int rol = entInt();
        if      (rol == 1) menuAdmin();
        else if (rol == 2) menuGestor();
        else System.out.println("Rol no vàlid.");
    }

    // ── MENÚ ADMIN ───────────────────────────────────────────────────
    private static void menuAdmin() {
        int op;
        do {
            System.out.println("\n=== ADMIN ===\n1-Classificació 🏆\n2-Alta equip\n3-Alta jugador/entrenador"
                + "\n4-Consultar equip\n5-Consultar jugador\n6-Nova lliga\n7-Entrenament mercat\n8-Desar\n0-Sortir");
            System.out.print("Opció: ");
            switch (op = entInt()) {
                case 1: classificacio(); break;
                case 2: altaEquip(); break;
                case 3: altaPersona(); break;
                case 4: consultarEquip(); break;
                case 5: consultarJugador(); break;
                case 6: novaLliga(); break;
                case 7: entrenamentMercat(); break;
                case 8: guardarEquips("equips.txt"); break;
            }
        } while (op != 0);
    }

    // ── MENÚ GESTOR ──────────────────────────────────────────────────
    private static void menuGestor() {
        Equip eq = triarEquip("El teu equip:");
        if (eq == null) return;
        int op;
        do {
            System.out.println("\n=== GESTOR: " + eq.getNom()
                + " ===\n1-Classificació 🏆\n2-Gestionar equip ⚽\n3-Consultar equip"
                + "\n4-Consultar jugador\n5-Transferir jugador\n6-Desar\n0-Sortir");
            System.out.print("Opció: ");
            switch (op = entInt()) {
                case 1: classificacio(); break;
                case 2: if (!submenuGestionar(eq)) op = 0; break;
                case 3: consultarEquip(); break;
                case 4: consultarJugador(); break;
                case 5: transferir(); break;
                case 6: guardarEquips("equips.txt"); break;
            }
        } while (op != 0);
    }

    // ── SUBMENÚ GESTIONAR EQUIP ──────────────────────────────────────
    // Retorna false si l'equip s'ha donat de baixa
    private static boolean submenuGestionar(Equip eq) {
        int op;
        do {
            System.out.println("\n-- GESTIONAR: " + eq.getNom()
                + " --\n1-Baixa equip\n2-Modificar president\n3-Destituir entrenador\n4-Fitxar\n0-Tornar");
            System.out.print("Opció: ");
            switch (op = entInt()) {
                case 1:
                    if (confirmar("Donar de baixa " + eq.getNom() + "?")) {
                        equips.remove(eq); System.out.println("Equip donat de baixa."); return false;
                    } break;
                case 2: modificarPresident(eq); break;
                case 3: destituirEntrenador(eq); break;
                case 4: fitxar(eq); break;
            }
        } while (op != 0);
        return true;
    }

    // ── FUNCIONALITATS ───────────────────────────────────────────────
    private static void classificacio() {
        if (lliga == null) System.out.println("No hi ha cap lliga disputada.");
        else lliga.mostrarClassificacio();
    }

    private static void altaEquip() {
        String nom;
        do { System.out.print("Nom equip: "); nom = entText();
             if (buscarEquip(nom) != null) System.out.println("Ja existeix, torna a provar.");
        } while (buscarEquip(nom) != null);
        System.out.print("Any fundació: "); int any = entInt();
        System.out.print("Ciutat: ");       String ciu = entText();
        String est = null, pres = null;
        if (confirmar("Afegir estadi?"))    { System.out.print("Estadi: ");    est  = entText(); }
        if (confirmar("Afegir president?")) { System.out.print("President: "); pres = entText(); }
        equips.add(new Equip(nom, any, ciu, est, pres));
        System.out.println("Equip creat. Total jugadors creats: " + Jugador.getComptador());
    }

    private static void altaPersona() {
        System.out.println("1-Jugador  2-Entrenador"); int op = entInt();
        System.out.print("Nom: ");    String nom    = entText();
        System.out.print("Cognom: "); String cognom = entText();
        System.out.print("Data (dd/MM/yyyy): "); LocalDate data = entData();
        System.out.print("Sou: ");    double sou = entDouble();
        if (op == 1) {
            System.out.print("Dorsal: "); int d = entInt();
            System.out.print("Posició (POR/DEF/MIG/DAV): ");
            Jugador.Posicio pos;
            try { pos = Jugador.Posicio.valueOf(entText().toUpperCase()); }
            catch (Exception e) { System.out.println("Posició no vàlida."); return; }
            Jugador j = new Jugador(nom, cognom, data, sou, d, pos);
            mercat.add(j);
            System.out.println("Jugador al mercat. Q=" + String.format("%.1f",j.getQualitat())
                + " | Total creats: " + Jugador.getComptador());
        } else if (op == 2) {
            System.out.print("Tornejos: "); int t = entInt();
            System.out.print("Seleccionador? (s/n): "); boolean sel = entText().equalsIgnoreCase("s");
            mentors.add(new Entrenador(nom, cognom, data, sou, t, sel));
            System.out.println("Entrenador al mercat.");
        }
    }

    private static void consultarEquip() {
        Equip eq = triarEquip("Nom de l'equip:"); if (eq == null) return; eq.mostrar();
    }

    private static void consultarJugador() {
        Equip eq = triarEquip("Equip:"); if (eq == null) return;
        System.out.print("Nom jugador: "); String nom = entText();
        System.out.print("Dorsal: ");      int d = entInt();
        Jugador j = eq.cercarJugador(nom, d);
        System.out.println(j != null ? j.toString() : "Jugador no trobat.");
    }

    private static void novaLliga() {
        if (equips.isEmpty()) { System.out.println("No hi ha equips."); return; }
        System.out.print("Nom lliga: "); String nom = entText();
        System.out.print("Nº equips: "); int max = entInt();
        lliga = new Lliga(nom, max);
        for (int i = 0; i < equips.size(); i++) System.out.println((i+1)+". "+equips.get(i).getNom());
        System.out.println("Afegeix equips (0=acabar):");
        while (true) { System.out.print("#: "); int i = entInt();
            if (i == 0) break;
            if (i >= 1 && i <= equips.size()) lliga.afegirEquip(equips.get(i-1));
        }
        if (lliga.getEquips().size() < 2) { System.out.println("Calen ≥2 equips."); lliga = null; return; }
        lliga.disputar(); lliga.mostrarClassificacio();
    }

    private static void entrenamentMercat() {
        System.out.println("--- ENTRENAMENT MERCAT ---");
        for (Jugador j : mercat)    { j.entrenament(); j.canviDePosicio(); }
        for (Entrenador e : mentors){ e.entrenament(); e.incrementarSou(); }
    }

    private static void modificarPresident(Equip eq) {
        System.out.println("President actual: " + (eq.getPresident() != null ? eq.getPresident() : "-"));
        System.out.print("Nou president (buit=treure): "); String p = entText();
        eq.setPresident(p.isEmpty() ? null : p);
        System.out.println("Actualitzat.");
    }

    private static void destituirEntrenador(Equip eq) {
        if (eq.getEntrenador() == null) { System.out.println("No té entrenador."); return; }
        if (!confirmar("Destituir " + eq.getEntrenador().getNom() + "?")) return;
        mentors.add(eq.getEntrenador()); eq.destituirEntrenador();
        System.out.println("Entrenador destituït. Torna al mercat.");
    }

    private static void fitxar(Equip eq) {
        System.out.println("1-Jugador  2-Entrenador"); int op = entInt();
        if (op == 1) {
            if (mercat.isEmpty()) { System.out.println("Mercat buit."); return; }
            List<Jugador> ord = new ArrayList<>(mercat);
            Collections.sort(ord, Jugador.comparadorMercat());
            for (int i = 0; i < ord.size(); i++) System.out.println((i+1)+". "+ord.get(i));
            System.out.print("Núm (0=cancel): "); int idx = entInt();
            if (idx < 1 || idx > ord.size()) return;
            Jugador j = ord.get(idx - 1);
            while (!eq.afegirJugador(j)) { System.out.print("Nou dorsal: "); j.setDorsal(entInt()); }
            mercat.remove(j); System.out.println(j.getNom() + " fitxat.");
        } else if (op == 2) {
            if (eq.getEntrenador() != null) { System.out.println("Destitueix l'actual primer."); return; }
            if (mentors.isEmpty()) { System.out.println("No hi ha entrenadors al mercat."); return; }
            for (int i = 0; i < mentors.size(); i++) System.out.println((i+1)+". "+mentors.get(i));
            System.out.print("Núm (0=cancel): "); int idx = entInt();
            if (idx < 1 || idx > mentors.size()) return;
            Entrenador e = mentors.get(idx - 1);
            eq.setEntrenador(e); mentors.remove(e); System.out.println(e.getNom() + " fitxat.");
        }
    }

    private static void transferir() {
        Equip ori = triarEquip("Equip origen:"); if (ori == null) return;
        Equip dst = triarEquip("Equip destí:");  if (dst == null) return;
        if (ori.getNom().equals(dst.getNom())) { System.out.println("Origen=destí. Error"); return; }
        System.out.print("Nom jugador: "); String nom = entText();
        System.out.print("Dorsal: ");      int d = entInt();
        Jugador j = ori.cercarJugador(nom, d);
        if (j == null) { System.out.println("No trobat."); return; }
        ori.eliminarJugador(j);
        while (!dst.afegirJugador(j)) { System.out.print("Dorsal ocupat. Nou dorsal: "); j.setDorsal(entInt()); }
        System.out.println(j.getNom() + " transferit a " + dst.getNom() + ".");
    }

    // ── FITXERS ──────────────────────────────────────────────────────
    private static void carregarMercat(String f) {
        File file = new File(f);
        if (!file.exists()) { System.out.println("Fitxer mercat no trobat."); return; }
        int j = 0, e = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String l;
            while ((l = br.readLine()) != null) {
                String[] c = l.trim().split(";");
                if (c[0].equals("J") && c.length >= 9) {
                    mercat.add(new Jugador(c[1],c[2],LocalDate.parse(c[3],FMT),
                        Double.parseDouble(c[4]),Double.parseDouble(c[5]),
                        Integer.parseInt(c[6]),Jugador.Posicio.valueOf(c[7]),Double.parseDouble(c[8]))); j++;
                } else if (c[0].equals("E") && c.length >= 8) {
                    mentors.add(new Entrenador(c[1],c[2],LocalDate.parse(c[3],FMT),
                        Double.parseDouble(c[4]),Double.parseDouble(c[5]),
                        Integer.parseInt(c[6]),Boolean.parseBoolean(c[7]))); e++;
                }
            }
        } catch (Exception ex) { System.out.println("Error mercat: "+ex.getMessage()); }
        System.out.println("Mercat: " + j + " jugadors, " + e + " entrenadors.");
    }

    private static void guardarEquips(String f) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
            for (Equip eq : equips) {
                pw.println("EQUIP;"+eq.getNom()+";"+eq.getAny()+";"+eq.getCiutat()
                    +";"+(eq.getEstadi()!=null?eq.getEstadi():"null")
                    +";"+(eq.getPresident()!=null?eq.getPresident():"null"));
                Entrenador en = eq.getEntrenador();
                if (en != null)
                    pw.println("ENTRENADOR;"+en.getNom()+";"+en.getCognom()
                        +";"+en.getDataNaixement().format(FMT)
                        +";"+en.getMotivacio()+";"+en.getSou()
                        +";"+en.getTornejos()+";"+en.isEsSeleccionador());
                else pw.println("ENTRENADOR;null");
                for (Jugador j : eq.getJugadors())
                    pw.println("JUGADOR;"+j.getNom()+";"+j.getCognom()
                        +";"+j.getDataNaixement().format(FMT)
                        +";"+j.getMotivacio()+";"+j.getSou()
                        +";"+j.getDorsal()+";"+j.getPosicio()+";"+j.getQualitat());
                pw.println("FI_EQUIP");
            }
            System.out.println("Equips desats a " + f);
        } catch (IOException ex) { System.out.println("Error desant: "+ex.getMessage()); }
    }

    private static void carregarEquips(String f) {
        File file = new File(f); if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String l; Equip ac = null;
            while ((l = br.readLine()) != null) {
                String[] c = l.trim().split(";");
                if (c[0].equals("EQUIP"))
                    ac = new Equip(c[1],Integer.parseInt(c[2]),c[3],
                        c[4].equals("null")?null:c[4], c[5].equals("null")?null:c[5]);
                else if (c[0].equals("ENTRENADOR") && ac!=null && !c[1].equals("null") && c.length>=8)
                    ac.setEntrenador(new Entrenador(c[1],c[2],LocalDate.parse(c[3],FMT),
                        Double.parseDouble(c[4]),Double.parseDouble(c[5]),
                        Integer.parseInt(c[6]),Boolean.parseBoolean(c[7])));
                else if (c[0].equals("JUGADOR") && ac!=null && c.length>=9)
                    ac.afegirJugador(new Jugador(c[1],c[2],LocalDate.parse(c[3],FMT),
                        Double.parseDouble(c[4]),Double.parseDouble(c[5]),
                        Integer.parseInt(c[6]),Jugador.Posicio.valueOf(c[7]),Double.parseDouble(c[8])));
                else if (c[0].equals("FI_EQUIP") && ac!=null) { equips.add(ac); ac=null; }
            }
            if (!equips.isEmpty()) System.out.println("Equips carregats: "+equips.size());
        } catch (Exception ex) { System.out.println("Error carregant equips: "+ex.getMessage()); }
    }

    // ── UTILITATS ────────────────────────────────────────────────────
    private static Equip buscarEquip(String nom) {
        for (Equip e : equips) if (e.getNom().equalsIgnoreCase(nom)) return e; return null;
    }
    private static Equip triarEquip(String msg) {
        if (equips.isEmpty()) { System.out.println("No hi ha equips."); return null; }
        System.out.println(msg);
        for (int i = 0; i < equips.size(); i++) System.out.println("  "+(i+1)+". "+equips.get(i).getNom());
        while (true) { System.out.print("Nom: ");
            Equip e = buscarEquip(entText()); if (e != null) return e;
            System.out.println("No trobat, torna a provar."); }
    }
    private static boolean confirmar(String msg) { System.out.print(msg+" (s/n): "); return entText().equalsIgnoreCase("s"); }
    private static int entInt()       { try { return Integer.parseInt(sc.nextLine().trim()); } catch(Exception e){return -1;} }
    private static double entDouble() { try { return Double.parseDouble(sc.nextLine().trim().replace(",",".")); } catch(Exception e){return 0;} }
    private static String entText()   { return sc.nextLine().trim(); }
    private static LocalDate entData(){ while(true){ try{return LocalDate.parse(sc.nextLine().trim(),FMT);}catch(Exception e){System.out.print("dd/MM/yyyy: ");}} }
}