package org.example;
import java.time.LocalDate;

public abstract class Persona {
    private final String nom, cognom;
    private final LocalDate dataNaixement;
    protected double motivacio, sou;

    public Persona(String nom, String cognom, LocalDate data, double motivacio, double sou) {
        this.nom = nom; this.cognom = cognom; this.dataNaixement = data;
        this.sou = sou; setMotivacio(motivacio);
    }
    public String getNom()           { return nom; }
    public String getCognom()        { return cognom; }
    public LocalDate getDataNaixement() { return dataNaixement; }
    public double getMotivacio()     { return motivacio; }
    public double getSou()           { return sou; }
    public void setSou(double s)     { sou = s; }
    public void setMotivacio(double m) { motivacio = Math.max(1, Math.min(10, m)); }
    public void entrenament()        { setMotivacio(motivacio + 0.2); }

    @Override public String toString() {
        return nom + " " + cognom + " | Mot:" + String.format("%.1f", motivacio)
             + " | Sou:" + String.format("%.0f", sou) + "EUR";
    }
}
