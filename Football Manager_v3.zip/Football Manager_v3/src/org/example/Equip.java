package org.example;
import java.util.*;

public class Equip {
    private final String nom;
    private int any; private String ciutat, estadi, president;
    private Entrenador entrenador;
    private List<Jugador> jugadors = new ArrayList<Jugador>();
    private int punts, gf, gc, pj;

    public Equip(String nom, int any, String ciutat, String estadi, String president) {
        this.nom = nom; this.any = any; this.ciutat = ciutat;
        this.estadi = estadi; this.president = president;
    }
    public Equip(String nom, int any, String ciutat) { this(nom, any, ciutat, null, null); }

    public String getNom()          { return nom; }
    public int getAny()             { return any; }
    public String getCiutat()       { return ciutat; }
    public String getEstadi()       { return estadi; }
    public String getPresident()    { return president; }
    public Entrenador getEntrenador(){ return entrenador; }
    public List<Jugador> getJugadors(){ return jugadors; }
    public int getPunts() { return punts; } public int getGF() { return gf; }
    public int getGC()    { return gc; }    public int getPJ() { return pj; }
    public int getDG()    { return gf - gc; }

    public void setPresident(String p) { president = p; }
    public void setEntrenador(Entrenador e) { entrenador = e; }
    public void destituirEntrenador() { entrenador = null; }

    public boolean afegirJugador(Jugador j) {
        for (Jugador x : jugadors) if (x.getDorsal() == j.getDorsal()) {
            System.out.println("Dorsal " + j.getDorsal() + " ocupat a " + nom); return false;
        }
        return jugadors.add(j);
    }
    public void eliminarJugador(Jugador j) { jugadors.remove(j); }

    public Jugador cercarJugador(String nom, int dorsal) {
        for (Jugador j : jugadors)
            if (j.getNom().equalsIgnoreCase(nom) && j.getDorsal() == dorsal) return j;
        return null;
    }

    public double qualitatMitjana() {
        if (jugadors.isEmpty()) return 0;
        double s = 0; for (Jugador j : jugadors) s += j.getQualitat(); return s / jugadors.size();
    }
    public double motivaciaMitjana() {
        if (jugadors.isEmpty()) return 5;
        double s = 0; for (Jugador j : jugadors) s += j.getMotivacio(); return s / jugadors.size();
    }

    public void reiniciarStats() { punts = gf = gc = pj = 0; }
    public void afegirResultat(int golsF, int golsC, int pts) {
        gf += golsF; gc += golsC; punts += pts; pj++;
    }

    public List<Jugador> jugadorsOrdenats() {
        List<Jugador> c = new ArrayList<Jugador>(jugadors);
        Collections.sort(c, Jugador.comparadorEquip()); return c;
    }

    public void mostrar() {
        System.out.println("Equip:     " + nom + " (" + any + ", " + ciutat + ")");
        System.out.println("Estadi:    " + (estadi != null ? estadi : "-"));
        System.out.println("President: " + (president != null ? president : "-"));
        System.out.println("Entrenador:" + (entrenador != null ? " " + entrenador : " -"));
        System.out.printf("Q.Mitjana: %.1f | Jugadors: %d%n", qualitatMitjana(), jugadors.size());
        for (Jugador j : jugadorsOrdenats()) System.out.println("  " + j);
    }

    @Override public String toString() {
        return String.format("%-20s %d %-15s Jug:%2d Entr:%s",
            nom, any, ciutat, jugadors.size(),
            entrenador != null ? entrenador.getNom() : "-");
    }
}
