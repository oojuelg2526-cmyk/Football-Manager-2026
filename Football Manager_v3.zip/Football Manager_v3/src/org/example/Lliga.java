package org.example;
import java.util.*;

public class Lliga {
    private String nom;
    private int max;
    private List<Equip> equips = new ArrayList<Equip>();

    public Lliga(String nom, int max) { this.nom = nom; this.max = max; }
    public List<Equip> getEquips() { return equips; }

    public boolean afegirEquip(Equip e) {
        if (equips.size() >= max) { System.out.println("Màxim d'equips assolit."); return false; }
        for (Equip x : equips) if (x.getNom().equalsIgnoreCase(e.getNom())) {
            System.out.println(e.getNom() + " ja és a la lliga."); return false;
        }
        equips.add(e); return true;
    }

    public void disputar() {
        if (equips.size() < 2) { System.out.println("Calen mínim 2 equips."); return; }
        System.out.println("\n=== LLIGA: " + nom + " ===");
        for (Equip e : equips) e.reiniciarStats();
        for (int i = 0; i < equips.size(); i++)
            for (int j = i+1; j < equips.size(); j++) {
                jugar(equips.get(i), equips.get(j));
                jugar(equips.get(j), equips.get(i));
            }
        System.out.println("=== FI ===\n");
    }

    private void jugar(Equip loc, Equip vis) {
        double fL = (loc.qualitatMitjana() + loc.motivaciaMitjana()) * 1.1;
        double fV =  vis.qualitatMitjana() + vis.motivaciaMitjana();
        int gL = 0, gV = 0;
        for (int i = 0; i < 5; i++) { if (Math.random() < fL/110) gL++; if (Math.random() < fV/110) gV++; }
        loc.afegirResultat(gL, gV, gL>gV ? 3 : gL==gV ? 1 : 0);
        vis.afegirResultat(gV, gL, gV>gL ? 3 : gL==gV ? 1 : 0);
        System.out.printf("  %-18s %d-%d %-18s%n", loc.getNom(), gL, gV, vis.getNom());
    }

    public void mostrarClassificacio() {
        List<Equip> c = new ArrayList<Equip>(equips);
        Collections.sort(c, new Comparator<Equip>() { public int compare(Equip a, Equip b) {
            if (b.getPunts() != a.getPunts()) return b.getPunts() - a.getPunts();
            return b.getDG() != a.getDG() ? b.getDG() - a.getDG() : b.getGF() - a.getGF();
        }});
        System.out.println("\n=== CLASSIFICACIÓ: " + nom + " ===");
        System.out.printf("%-3s %-20s %4s %3s %3s %3s %3s%n","Pos","Equip","Pts","PJ","GF","GC","DG");
        System.out.println("-".repeat(42));
        int pos = 1;
        for (Equip e : c)
            System.out.printf("%-3d %-20s %4d %3d %3d %3d %3d%n",
                pos++, e.getNom(), e.getPunts(), e.getPJ(), e.getGF(), e.getGC(), e.getDG());
        // Màxims
        Equip mGF = c.get(0), mGC = c.get(0);
        for (Equip e : c) { if (e.getGF() > mGF.getGF()) mGF=e; if (e.getGC() > mGC.getGC()) mGC=e; }
        System.out.println("\nMàx. golejador:  " + mGF.getNom() + " (" + mGF.getGF() + ")");
        System.out.println("Màx. encaixador: " + mGC.getNom() + " (" + mGC.getGC() + ")\n");
    }
}
